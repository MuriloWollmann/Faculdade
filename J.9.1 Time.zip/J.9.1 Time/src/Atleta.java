public class Atleta {
    String nome;
    int idade;
    String posicao;

    Atleta(String nome, int idade, String posicao) {
        this.nome = nome;
        this.idade = idade;
        this.posicao = posicao;
    }
}
